from Model.base_model import BaseScreenModel


class MainappScreenModel(BaseScreenModel):
    """
    Implements the logic of the
    :class:`~View.mainapp_screen.MainappScreen.MainappScreenView` class.
    """